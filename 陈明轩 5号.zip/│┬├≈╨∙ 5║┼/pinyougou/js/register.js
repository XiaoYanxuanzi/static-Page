function register() {
    var tel = document.getElementById("tel");
    var captcha = document.getElementById("captcha");
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm_password");
    

    if (tel.value == "") {

        alert("请输入手机号");
        
    } else if (captcha.value == "") {

        alert("请输入验证码");

    } else if (password.value == "") {

        alert("请输入密码");

    } else if (confirm_password.value == "") {

        alert("请再次输入密码");

    } else if (tel.value != "" && password.value != "" &&
        confirm_password.value == password.value && captcha.value != "") {

        window.location.href = "index.html";

    } else if (confirm_password.value != password.value) {

        alert("你两次密码不相同，请重新输入");

    }
}

function checkAgreement() {
    if (document.getElementById("agreement").checked == false) {

        alert("不同意协议不能注册");

        document.getElementById("agreement").focus();
        
        return false;
    }
    return true;
}

